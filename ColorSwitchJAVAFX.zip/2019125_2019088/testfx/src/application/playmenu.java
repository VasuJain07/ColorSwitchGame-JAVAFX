package application;

import javafx.geometry.Pos;
import javafx.scene.paint.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

import javafx.animation.RotateTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.control.*;
import javafx.scene.effect.BlendMode;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;


public class playmenu{
	public Stage stage;
	public String playername;
    public playmenu(Stage stage,String playername) {
    	this.stage=stage;
    	this.playername=playername;
    }
    public void start()
    {

        Image imagebg=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\giphy.gif");
        ImageView iwbg=new ImageView(imagebg);
        iwbg.setFitHeight(700);
        iwbg.setFitWidth(700);
        iwbg.setRotate(90);

        Image image3=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\newgame.png");
        ImageView pb=new ImageView(image3);
        pb.setFitHeight(100);
        pb.setFitWidth(250);
        //pb.relocate(20, 100);
        Button b = new Button("",pb);
        b.relocate(250, 250);
        b.setOnMouseEntered((event) -> {    
            b.setBlendMode(BlendMode.BLUE);
        });
        b.setOnMouseExited((event) -> {    
            b.setBlendMode(null);
        });
        b.setOnAction((event) -> {    // lambda expression
            //ToggleButton source = (ToggleButton) event.getSource();
            gameplay e=new gameplay(stage,playername);
//            Stage stage2=new Stage();
            e.start();
//            stage.close();
        });

        Image image4=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\loadgame.png");
        ImageView pb1=new ImageView(image4);
        pb1.setFitHeight(100);
        pb1.setFitWidth(250);
        //pb.relocate(20, 100);
        Button b2 = new Button("",pb1);
        b2.relocate(250, 350);
        b2.setOnMouseEntered((event) -> {    
            b2.setBlendMode(BlendMode.BLUE);
        });
        b2.setOnMouseExited((event) -> {    
            b2.setBlendMode(null);
        });
        
        b2.setOnAction((event) -> { 
//        	System.out.println("clicked");
		Loader runner=new Loader(stage,playername);
		runner.start();
        });
        
        

        Image image5=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\Exit.png");
        ImageView pb2=new ImageView(image5);
        pb2.setFitHeight(100);
        pb2.setFitWidth(250);
        //pb.relocate(20, 100);
        Button b3 = new Button("",pb2);
        b3.relocate(250, 450);
        b3.setOnMouseEntered((event) -> {    
            b3.setBlendMode(BlendMode.BLUE);
        });
        b3.setOnMouseExited((event) -> {    
            b3.setBlendMode(null);
        });
        
        b3.setOnAction((event) -> {    // lambda expression
            //ToggleButton source = (ToggleButton) event.getSource();
            Main e=new Main();
            Stage stage2=new Stage();
            e.start(stage2);
            stage.close();
        });

        Image image6=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\unnamed.png");
        ImageView pb4=new ImageView(image6);
        pb4.setFitHeight(50);
        pb4.setFitWidth(50);
//        pb.relocate(20, 100);
        Button b4 = new Button("",pb4);
        b4.setOnAction((event) -> {    // lambda expression
            //ToggleButton source = (ToggleButton) event.getSource();
            enternameclass e=new enternameclass(stage);
//            Stage stage2=new Stage();
            e.start();
//            stage.close();
        });
        b4.setOnMouseEntered((event) -> {    
            b4.setBlendMode(BlendMode.RED);
        });
        b4.setOnMouseExited((event) -> {    
            b4.setBlendMode(null);
        });
//        b.setGraphic(pb);
//        b.resize(50, 50);
        b4.relocate(25, 50);

        BorderPane vbox2 = new BorderPane();

        StackPane vbox1=new StackPane();
        vbox1.getChildren().add(vbox2);
        vbox2.setMaxSize(500, 700);
        vbox2.setMinSize(500, 700);
        {
            vbox2.getChildren().add(iwbg);
            vbox2.getChildren().add(b);
            vbox2.getChildren().add(b2);
            vbox2.getChildren().add(b3);
            vbox2.getChildren().add(b4);
        }
        Scene sc = new Scene(vbox1, 500,650);
        stage.setResizable(true);

        stage.setScene(sc);

        stage.show();
    }
}