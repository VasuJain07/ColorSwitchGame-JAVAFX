package application;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

import javafx.animation.RotateTransition;
import javafx.util.Duration;
class savegame implements Serializable {
	String playerName;
    ArrayList<Double> yCord;
    ArrayList<Integer> obsId;
//    ArrayList<RotateTransition> rots;
    ArrayList<Duration> durations;
    String color;//ballcolor
    int score;

    public savegame(ArrayList<RotateTransition> rots,ArrayList<Obstacle> obsList, Ball ball, String playerName,int score) {
        this.playerName = playerName;
        color=ball.getcolor();
        this.score=score;
        yCord = new ArrayList<>();
        obsId = new ArrayList<>();
        durations = new ArrayList<>();

        yCord.add(ball.Position[1]);
//        obsId.add(0);
        durations.add(Duration.ZERO);

//        for (Obstacle obstacle : obsList) {
        for(int i=0;i<obsList.size();i++) {
        	Obstacle obstacle=obsList.get(i);
//            yCord.add(obstacle.);
//            angle.add(obstacle.getRotate());
            if (obstacle instanceof Square) {
                obsId.add(1);
                yCord.add(((Square)obstacle).Position[1]);
//                System.out.println(((Square)obstacle).Position[1]);
                durations.add(rots.get(i).getCurrentTime());
            }
            else if (obstacle instanceof Circular) {
                obsId.add(2);
                yCord.add(((Circular)obstacle).Position[1]);
                durations.add(rots.get(i).getCurrentTime());
            }
            else if (obstacle instanceof Plus) {
                obsId.add(3);
                yCord.add(((Plus)obstacle).Position[1]);
                durations.add(rots.get(i).getCurrentTime());
            }
            else if (obstacle instanceof Starobs) {
                obsId.add(4);
                yCord.add(((Starobs)obstacle).Position[1]);
                durations.add(rots.get(i).getCurrentTime());
            }
            else if (obstacle instanceof Triangle) {
                obsId.add(5);
                yCord.add(((Triangle)obstacle).Position[1]);
                durations.add(rots.get(i).getCurrentTime());
            }
            else if (obstacle instanceof Colorswitch) {
                obsId.add(6);
                yCord.add(((Colorswitch)obstacle).Position[1]);
                System.out.println(((Colorswitch)obstacle).Position[1]);
                durations.add(rots.get(i).getCurrentTime());
            }
        }
    }

    public void saveGame(){
        try{
            FileOutputStream writeData = new FileOutputStream(playerName+".txt");
            ObjectOutputStream writeStream = new ObjectOutputStream(writeData);
            writeStream.writeObject(this);
            writeStream.flush();
            writeStream.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}