package application;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.effect.BlendMode;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Players {
	public Scene sc;
    Stage stage;
    HashMap<String,Integer> allhighscores=new HashMap<String,Integer>();
    int height=50;
    
    Players(Stage stage,HashMap<String,Integer> ref){
    	this.allhighscores=ref;
    	this.stage=stage;
    	this.start();
    }
    
    public void start(){
    	Media hs = new Media(getClass().getResource("button.wav").toString());
//		Media hs= new Media("jump.mp3");
		MediaPlayer mediaPlayerHS = new MediaPlayer(hs);
		
		{
			mediaPlayerHS.setAutoPlay(false);
			mediaPlayerHS.setCycleCount(1);
		
		}
    	BorderPane vbox2 = new BorderPane();
    	StackPane vbox1=new StackPane();
    	vbox1.getChildren().add(vbox2);
        vbox2.setMaxSize(500, 700);
        vbox2.setMinSize(500, 700);
        Iterator<Map.Entry<String, Integer>> itr = allhighscores.entrySet().iterator(); 
        Image imagebg=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\hypno.gif");

        ImageView iwbg=new ImageView(imagebg);
        iwbg.setFitHeight(700);
        iwbg.setFitWidth(500);

        Image image3=new Image("file:D:\\\\\\\\STUDY\\\\\\\\SEM_3\\\\\\\\AP\\\\\\\\unnamed.png");
        ImageView pb=new ImageView(image3);
        pb.setFitHeight(50);
        pb.setFitWidth(50);
//        pb.relocate(20, 100);
        Button b = new Button("",pb);
        b.relocate(25, 25);
        b.setOnAction((event) -> {    // lambda expression
            //ToggleButton source = (ToggleButton) event.getSource();
        	mediaPlayerHS.play();
            Main e=new Main();
//            Stage stage2=new Stage();
            e.start(stage);
//            stage.close();
        });
        b.setOnMouseEntered((event) -> {    
            b.setBlendMode(BlendMode.RED);
        });
        b.setOnMouseExited((event) -> {    
            b.setBlendMode(null);
        });
        vbox2.getChildren().add(iwbg);
        vbox2.getChildren().add(b);
        while(itr.hasNext()) 
        { 
             Map.Entry<String, Integer> entry = itr.next(); 
             Text toadder=new Text("Player:" + entry.getKey() +  ",Highscore:" + entry.getValue());
             toadder.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
             toadder.autosize();
             toadder.setFill(Color.WHITESMOKE);
             toadder.relocate(20, height);
             height+=40;
             System.out.println("values is being added");
             vbox2.getChildren().add(toadder);
        } 
        sc = new Scene(vbox1, 500,700);
        stage.setResizable(true);
        stage.setScene(sc);

//        stage.setScene(sc);

        stage.show();
    }
    
}
