//package application;
//import javafx.animation.Interpolator;
//import javafx.animation.RotateTransition;
//import javafx.animation.Timeline;
//import javafx.animation.TranslateTransition;
//import javafx.scene.Group;
//import javafx.scene.Node;
//import javafx.scene.image.Image;
//import javafx.scene.image.ImageView;
//import javafx.scene.paint.Color;
//import javafx.scene.paint.ImagePattern;
//import javafx.scene.shape.Circle;
//import javafx.scene.shape.Line;
//import javafx.util.Duration;
//
//public class Triangle extends Elements implements Obstacle {
//    private float Speed;
//    private float Size;
//    private String ballcolor;
//    public RotateTransition boxy;
//
//
//    public Triangle(float s, String ballcoloris) {
//        this.Size=s;
//        this.ballcolor=ballcoloris;
//        System.out.println(ballcoloris);
//    }
//    @Override
//    public float getSpeed() {
//        return Speed;
//    }
//    @Override
//    public void setSpeed(float Speed) {
//        this.Speed=Speed;
//    }
//    public Group action(){
//        int counter=0;
//
//        Line linep=new Line(0,0,Size,0);
//        linep.setStrokeWidth(30);	
//        linep.setStroke(Color.MEDIUMPURPLE);
//        linep.relocate(Size,Size);
//
//        Line liney=new Line(0,0,Size,0);
//        liney.setStrokeWidth(30);
//        
//        liney.setStroke(Color.YELLOW);
//        liney.relocate(Size,2*Size);
//        
//        Group boxy=new Group(liney,linep);
//        boxy.relocate(125, -150);
//        return boxy;
//    }
//    public void setSize(float size) {
//        this.Size=size;
//    }
//    @Override
//    public float getSize() {
//        return this.Size;
//    }
//    public void annimate(Group box) {
//        boxy=new RotateTransition(Duration.seconds(3),box);
//        boxy.setByAngle(360);
//        boxy.setCycleCount(Timeline.INDEFINITE);
//        boxy.setInterpolator(Interpolator.LINEAR);
////       rot3.setDelay(Duration.ZERO);
//        boxy.play();
//    }
//
//}
package application;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.util.Duration;

public class Triangle extends Elements implements Obstacle {
    private float Speed;
    private float Size;
    private String ballcolor;
    public RotateTransition boxy;


    public Triangle(float s, String ballcoloris) {
        this.Size=s;
    }
    @Override
    public float getSpeed() {
        return Speed;
    }
    @Override
    public void setSpeed(float Speed) {
        this.Speed=Speed;
    }
    public Group action(){
        Line linep=new Line(0,0,1.5*Size,0);
        linep.setStrokeWidth(20);
        linep.setStroke(Color.MEDIUMPURPLE);
        linep.relocate(Size,Size);

        Line liney=new Line(0,0,1.5*Size,0);
        liney.setStrokeWidth(20);
        liney.setStroke(Color.YELLOW);
        liney.relocate(Size,2*Size);

        Circle starb=new Circle(30);
        starb.relocate(3*Size/2-15, 3*Size/2-15);

        Image image = new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\star.png");
        ImagePattern imagePattern = new ImagePattern(image);
        starb.setFill(imagePattern);

        Group box=new Group(linep,liney,starb);
        box.relocate(140,-150);
        return box;
    }
    public void setSize(float size) {
        this.Size=size;
    }
    @Override
    public float getSize() {
        return this.Size;
    }
    public void annimate(Group box) {
        boxy=new RotateTransition(Duration.seconds(3),box);
        boxy.setByAngle(360);
        boxy.setCycleCount(Timeline.INDEFINITE);
        boxy.setInterpolator(Interpolator.LINEAR);
//       rot3.setDelay(Duration.ZERO);
        boxy.play();
    }

}