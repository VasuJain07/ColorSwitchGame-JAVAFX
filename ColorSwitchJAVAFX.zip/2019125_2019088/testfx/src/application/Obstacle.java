package application;

import javafx.scene.Group;

public interface Obstacle {
	public float getSpeed();
	public void setSpeed(float speed);
	public Group action();
	public float getSize();
	public void annimate(Group t);
	public void setSize(float size);
}
