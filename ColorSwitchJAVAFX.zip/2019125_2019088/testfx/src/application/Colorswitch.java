package application;

import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;

public class Colorswitch extends Elements implements Obstacle {
//    public Group Colorswitch()
//    {
//        Circle starb=new Circle(25);
//        starb.relocate(100, 50);
//
//        Image image = new Image("file:/Users/rasagyashokeen/Downloads/exit2.png");
//        ImagePattern imagePattern = new ImagePattern(image);
//        starb.setFill(imagePattern);
//        Group colourswitch=new Group(starb);
//        return colourswitch;
//    }
    public Group action() {
        Circle starb=new Circle(25);
        starb.relocate(220, -150);
        starb.setStroke(Color.BLACK);
        Image image = new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\colorswitch.png");
        ImagePattern imagePattern = new ImagePattern(image);
        starb.setFill(imagePattern);
        Group colourswitch=new Group(starb);
        return colourswitch;
    }

@Override
public float getSpeed() {
	// TODO Auto-generated method stub
	return 0;
}

@Override
public void setSpeed(float speed) {
	// TODO Auto-generated method stub
	
}

@Override
public float getSize() {
	// TODO Auto-generated method stub
	return 0;
}

@Override
public void annimate(Group t) {
	// TODO Auto-generated method stub
	
}

@Override
public void setSize(float size) {
	// TODO Auto-generated method stub
	
}
}