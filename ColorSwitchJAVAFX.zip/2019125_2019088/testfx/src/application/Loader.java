package application;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.effect.BlendMode;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Loader {
    public Scene sc;
    Button game1 = new Button();
    Button game2 = new Button();
    public Stage stage;
    StackPane vbox1;
    String playername;

    public Loader(Stage stage,String playername) {
        this.stage = stage;
        this.playername=playername;
//		stage.setScene(sc);
        this.start();
//		sc=new Scene(vbox1,500,500);
    }

    public void start() {
    	Media hs = new Media(getClass().getResource("button.wav").toString());
//		Media hs= new Media("jump.mp3");
		MediaPlayer mediaPlayerHS = new MediaPlayer(hs);
		
		{
			mediaPlayerHS.setAutoPlay(false);
			mediaPlayerHS.setCycleCount(1);
		
		}

        Image imagebg=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\hypno.gif");
//        Image imagebg = new Image("file:/Users/rasagyashokeen/Downloads/black2.jpg");

        ImageView iwbg = new ImageView(imagebg);
        iwbg.setFitHeight(700);
        iwbg.setFitWidth(500);
        
        Image image3=new Image("file:D:\\\\\\\\STUDY\\\\\\\\SEM_3\\\\\\\\AP\\\\\\\\unnamed.png");
        ImageView pb=new ImageView(image3);
        pb.setFitHeight(50);
        pb.setFitWidth(50);
        
        Button b = new Button("",pb);
        b.relocate(25, 25);
        b.setOnAction((event) -> {    // lambda expression
            //ToggleButton source = (ToggleButton) event.getSource();
        	mediaPlayerHS.play();
            playmenu e=new playmenu(stage,playername);
//            Stage stage2=new Stage();
            e.start();
//            stage.close();
        });
        b.setOnMouseEntered((event) -> {    
            b.setBlendMode(BlendMode.RED);
        });
        b.setOnMouseExited((event) -> {    
            b.setBlendMode(null);
        });
        
        Image image5 = new Image("file:D:\\\\\\\\STUDY\\\\\\\\SEM_3\\\\\\\\AP\\\\\\\\game1.png");
        ImageView pbi = new ImageView(image5);
        pbi.setFitHeight(100);
        pbi.setFitWidth(250);
        //pb.relocate(20, 100);
        /* Button */
        game1 = new Button("", pbi);
        game1.relocate(250, 250);
        game1.setOnMouseEntered((event) -> {
            game1.setBlendMode(BlendMode.BLUE);
        });
        game1.setOnMouseExited((event) -> {
            game1.setBlendMode(null);
        });
        game1.setOnMouseClicked((event) -> {
        	mediaPlayerHS.play();
        		try
                {    
                    // Reading the object from a file 
            		savegame saver;
            		File file1=new File(playername+""+1+".txt");
                    FileInputStream file = new FileInputStream(file1); 
                    ObjectInputStream in = new ObjectInputStream(file); 
                      
                    // Method for deserialization of object 
                    saver = (savegame)in.readObject(); 
                      
                    in.close(); 
                    file.close(); 
                      
                    System.out.println("Object has been deserialized "); 
                    gameplay toload=new gameplay(stage,playername);
                   
                    toload.Score=saver.score;             
                    
                    toload.start();     
                	
                    toload.vbox2.getChildren().remove(toload.vbox2.getChildren().size()-1);

                    toload.bally.getBall().relocate(250, saver.yCord.get(0));

                    for(int i=0;i<saver.obsId.size();i++) {
                    	
                    	if(saver.obsId.get(i)==1) {
                    		Square temps=new Square(200);
                    		if(toload.allhurdle.size()>i) {
                    		toload.allobs.set(i,temps);
                    		toload.allhurdle.set(i,temps.action());}
                    		else {
                        		toload.allobs.add(temps);
                        		toload.allhurdle.add(temps.action());
                    		}
                    		toload.allhurdle.get(i).setRotate((saver.durations.get(i+1).toSeconds()%3)*120);
                    		
                    	}
                    	else if(saver.obsId.get(i)==2) {
                    		Circular tempc=new Circular();
                    		if(toload.allhurdle.size()>i) {
    	                		toload.allobs.set(i,tempc);
    	                		toload.allhurdle.set(i,tempc.action());}
                    		else {
    	                		toload.allobs.add(tempc);
    	                		toload.allhurdle.add(tempc.action());
                    		}
                    		toload.allhurdle.get(i).setRotate((saver.durations.get(i+1).toSeconds()%3)*120);
                    	}
                    	else if(saver.obsId.get(i)==3) {
                    		Plus tempp=new Plus(200);
                    		if(toload.allhurdle.size()>i) {
    	                		toload.allobs.set(i,tempp);
    	                		toload.allhurdle.set(i,tempp.action());
                    		}
                    		else {
    	                		toload.allobs.add(tempp);
    	                		toload.allhurdle.add(tempp.action());
                    		}
                    		toload.allhurdle.get(i).setRotate((saver.durations.get(i+1).toSeconds()%3)*120);
                    	}
                    	else if(saver.obsId.get(i)==4) {
                    		Starobs tempst=new Starobs(200);
                    		if(toload.allhurdle.size()>i) {
    	                		toload.allobs.set(i,tempst);
    	                		toload.allhurdle.set(i,tempst.action());
                    		}
                    		else{
                    			toload.allobs.add(tempst);
                    			toload.allhurdle.add(tempst.action());
                    		}
                    		toload.allhurdle.get(i).setRotate((saver.durations.get(i+1).toSeconds()%3)*120);
                    	}
                    	else if(saver.obsId.get(i)==5) {
                    		Triangle temptr=new Triangle(200,saver.color);
                    		
                    		if(toload.allhurdle.size()>i) {
                    			toload.allobs.set(i,temptr);
    	                		toload.allhurdle.set(i,temptr.action());}
                    		else {
                    			toload.allobs.add(temptr);
                        		toload.allhurdle.add(temptr.action());
                    		}
                    		toload.allhurdle.get(i).setRotate((saver.durations.get(i+1).toSeconds()%3)*120);
                    	}
                    	else if(saver.obsId.get(i)==6) {
                    		Colorswitch tempcs=new Colorswitch();
                    		
                    		if(toload.allhurdle.size()>i) {
    	                		toload.allobs.set(i,tempcs);
    	                		toload.allhurdle.set(i,tempcs.action());
                    		}
                    		else {
                    			toload.allobs.add(tempcs);
                        		toload.allhurdle.add(tempcs.action());
                    		}
//                    		toload.allhurdle.get(toload.allhurdle.size()-1).setRotate((saver.durations.get(i).toSeconds()%3)*120);
                    	}
                    	toload.allhurdle.get(i).setTranslateY(saver.yCord.get(i+1));
                    	toload.allhurdle.get(i).setRotate((saver.durations.get(i+1).toSeconds()%3)*120);

      
                    	System.out.println(toload.allhurdle.size()+" , "+saver.yCord.size()+" , "+toload.allobs.size()+" , "+saver.obsId.size());
                    	System.out.println("durations size:"+saver.durations.size());
                    }
                    System.out.println(saver.yCord);

                    toload.vbox2.getChildren().add(toload.allhurdle.get(0));

                    for (int i = 0; i < toload.allhurdle.size(); i++) {
            			toload.annimate(toload.allhurdle.get(i));
            		}

                    System.out.println(saver.yCord.get(0));
                    System.out.println("durations:"+saver.durations);
                    if(saver.color.equalsIgnoreCase("0x9370dbff")) {
                        toload.bally.setcolor(Color.MEDIUMPURPLE);
                    }
                    else if(saver.color.equalsIgnoreCase("0xffff00ff")) {
                        toload.bally.setcolor(Color.YELLOW);
                    }
                    else if(saver.color.equalsIgnoreCase("0xff1493ff")) {
                        toload.bally.setcolor(Color.DEEPPINK);
                    }
                    else if(saver.color.equalsIgnoreCase("0x00bfffff")) {
                        toload.bally.setcolor(Color.DEEPSKYBLUE);
                    }
                    
                    
                } 
                  
                catch(IOException ex) 
                { 
                    System.out.println("IOException is caught"); 
                } 
                  
                catch(ClassNotFoundException ex) 
                { 
                    System.out.println("ClassNotFoundException is caught"); 
                } 
        		
        		
        });
        Image image4 = new Image("file:D:\\\\\\\\STUDY\\\\\\\\SEM_3\\\\\\\\AP\\\\\\\\game2.png");
        ImageView pb1 = new ImageView(image4);
        pb1.setFitHeight(100);
        pb1.setFitWidth(250);
        //pb.relocate(20, 100);
        /* Button */
        game2 = new Button("", pb1);
        game2.relocate(250, 350);
        game2.setOnMouseEntered((event) -> {
            game2.setBlendMode(BlendMode.BLUE);
        });
        game2.setOnMouseExited((event) -> {
            game2.setBlendMode(null);
        });
        game2.setOnMouseClicked((event) -> {
        	mediaPlayerHS.play();
    		try
            {    
                // Reading the object from a file 
        		savegame saver;
        		File file1=new File(playername+""+2+".txt");
                FileInputStream file = new FileInputStream(file1); 
                ObjectInputStream in = new ObjectInputStream(file); 
                  
                // Method for deserialization of object 
                saver = (savegame)in.readObject(); 
                  
                in.close(); 
                file.close(); 
                  
                System.out.println("Object has been deserialized "); 
                gameplay toload=new gameplay(stage,playername);
               
                toload.Score=saver.score;             
                
                toload.start();     
            	
                toload.vbox2.getChildren().remove(toload.vbox2.getChildren().size()-1);

                toload.bally.getBall().relocate(250, saver.yCord.get(0));

                for(int i=0;i<saver.obsId.size();i++) {
                	
                	if(saver.obsId.get(i)==1) {
                		Square temps=new Square(200);
                		if(toload.allhurdle.size()>i) {
                		toload.allobs.set(i,temps);
                		toload.allhurdle.set(i,temps.action());}
                		else {
                    		toload.allobs.add(temps);
                    		toload.allhurdle.add(temps.action());
                		}
                		toload.allhurdle.get(i).setRotate((saver.durations.get(i+1).toSeconds()%3)*120);
                		
                	}
                	else if(saver.obsId.get(i)==2) {
                		Circular tempc=new Circular();
                		if(toload.allhurdle.size()>i) {
	                		toload.allobs.set(i,tempc);
	                		toload.allhurdle.set(i,tempc.action());}
                		else {
	                		toload.allobs.add(tempc);
	                		toload.allhurdle.add(tempc.action());
                		}
                		toload.allhurdle.get(i).setRotate((saver.durations.get(i+1).toSeconds()%3)*120);
                	}
                	else if(saver.obsId.get(i)==3) {
                		Plus tempp=new Plus(200);
                		if(toload.allhurdle.size()>i) {
	                		toload.allobs.set(i,tempp);
	                		toload.allhurdle.set(i,tempp.action());
                		}
                		else {
	                		toload.allobs.add(tempp);
	                		toload.allhurdle.add(tempp.action());
                		}
                		toload.allhurdle.get(i).setRotate((saver.durations.get(i+1).toSeconds()%3)*120);
                	}
                	else if(saver.obsId.get(i)==4) {
                		Starobs tempst=new Starobs(200);
                		if(toload.allhurdle.size()>i) {
	                		toload.allobs.set(i,tempst);
	                		toload.allhurdle.set(i,tempst.action());
                		}
                		else{
                			toload.allobs.add(tempst);
                			toload.allhurdle.add(tempst.action());
                		}
                		toload.allhurdle.get(i).setRotate((saver.durations.get(i+1).toSeconds()%3)*120);
                	}
                	else if(saver.obsId.get(i)==5) {
                		Triangle temptr=new Triangle(200,saver.color);
                		
                		if(toload.allhurdle.size()>i) {
                			toload.allobs.set(i,temptr);
	                		toload.allhurdle.set(i,temptr.action());}
                		else {
                			toload.allobs.add(temptr);
                    		toload.allhurdle.add(temptr.action());
                		}
                		toload.allhurdle.get(i).setRotate((saver.durations.get(i+1).toSeconds()%3)*120);
                	}
                	else if(saver.obsId.get(i)==6) {
                		Colorswitch tempcs=new Colorswitch();
                		
                		if(toload.allhurdle.size()>i) {
	                		toload.allobs.set(i,tempcs);
	                		toload.allhurdle.set(i,tempcs.action());
                		}
                		else {
                			toload.allobs.add(tempcs);
                    		toload.allhurdle.add(tempcs.action());
                		}
//                		toload.allhurdle.get(toload.allhurdle.size()-1).setRotate((saver.durations.get(i).toSeconds()%3)*120);
                	}
                	toload.allhurdle.get(i).setTranslateY(saver.yCord.get(i+1));
                	toload.allhurdle.get(i).setRotate((saver.durations.get(i+1).toSeconds()%3)*120);

  
                	System.out.println(toload.allhurdle.size()+" , "+saver.yCord.size()+" , "+toload.allobs.size()+" , "+saver.obsId.size());
                	System.out.println("durations size:"+saver.durations.size());
                }
                System.out.println(saver.yCord);

                toload.vbox2.getChildren().add(toload.allhurdle.get(0));

                for (int i = 0; i < toload.allhurdle.size(); i++) {
        			toload.annimate(toload.allhurdle.get(i));
        		}

                System.out.println(saver.yCord.get(0));
                System.out.println("durations:"+saver.durations);
                if(saver.color.equalsIgnoreCase("0x9370dbff")) {
                    toload.bally.setcolor(Color.MEDIUMPURPLE);
                }
                else if(saver.color.equalsIgnoreCase("0xffff00ff")) {
                    toload.bally.setcolor(Color.YELLOW);
                }
                else if(saver.color.equalsIgnoreCase("0xff1493ff")) {
                    toload.bally.setcolor(Color.DEEPPINK);
                }
                else if(saver.color.equalsIgnoreCase("0x00bfffff")) {
                    toload.bally.setcolor(Color.DEEPSKYBLUE);
                }
                
                
            } 
              
            catch(IOException ex) 
            { 
                System.out.println("IOException is caught"); 
            } 
              
            catch(ClassNotFoundException ex) 
            { 
                System.out.println("ClassNotFoundException is caught"); 
            } 
    		
    		
    });
        Image image10 = new Image("file:D:\\\\\\\\STUDY\\\\\\\\SEM_3\\\\\\\\AP\\\\\\\\game3.png");
        ImageView pb2 = new ImageView(image10);
        pb2.setFitHeight(100);
        pb2.setFitWidth(250);
        //pb.relocate(20, 100);
        Button game3 = new Button("", pb2);
        game3.relocate(250, 450);
        game3.setOnMouseEntered((event) -> {
            game3.setBlendMode(BlendMode.BLUE);
        });
        game3.setOnMouseExited((event) -> {
            game3.setBlendMode(null);
        });
        game3.setOnMouseClicked((event) -> {
        	mediaPlayerHS.play();
    		try
            {    
                // Reading the object from a file 
        		savegame saver;
        		File file1=new File(playername+""+3+".txt");
                FileInputStream file = new FileInputStream(file1); 
                ObjectInputStream in = new ObjectInputStream(file); 
                  
                // Method for deserialization of object 
                saver = (savegame)in.readObject(); 
                  
                in.close(); 
                file.close(); 
                  
                System.out.println("Object has been deserialized "); 
                gameplay toload=new gameplay(stage,playername);
               
                toload.Score=saver.score;             
                
                toload.start();     
            	
                toload.vbox2.getChildren().remove(toload.vbox2.getChildren().size()-1);

                toload.bally.getBall().relocate(250, saver.yCord.get(0));

                for(int i=0;i<saver.obsId.size();i++) {
                	
                	if(saver.obsId.get(i)==1) {
                		Square temps=new Square(200);
                		if(toload.allhurdle.size()>i) {
                		toload.allobs.set(i,temps);
                		toload.allhurdle.set(i,temps.action());}
                		else {
                    		toload.allobs.add(temps);
                    		toload.allhurdle.add(temps.action());
                		}
                		toload.allhurdle.get(i).setRotate((saver.durations.get(i+1).toSeconds()%3)*120);
                		
                	}
                	else if(saver.obsId.get(i)==2) {
                		Circular tempc=new Circular();
                		if(toload.allhurdle.size()>i) {
	                		toload.allobs.set(i,tempc);
	                		toload.allhurdle.set(i,tempc.action());}
                		else {
	                		toload.allobs.add(tempc);
	                		toload.allhurdle.add(tempc.action());
                		}
                		toload.allhurdle.get(i).setRotate((saver.durations.get(i+1).toSeconds()%3)*120);
                	}
                	else if(saver.obsId.get(i)==3) {
                		Plus tempp=new Plus(200);
                		if(toload.allhurdle.size()>i) {
	                		toload.allobs.set(i,tempp);
	                		toload.allhurdle.set(i,tempp.action());
                		}
                		else {
	                		toload.allobs.add(tempp);
	                		toload.allhurdle.add(tempp.action());
                		}
                		toload.allhurdle.get(i).setRotate((saver.durations.get(i+1).toSeconds()%3)*120);
                	}
                	else if(saver.obsId.get(i)==4) {
                		Starobs tempst=new Starobs(200);
                		if(toload.allhurdle.size()>i) {
	                		toload.allobs.set(i,tempst);
	                		toload.allhurdle.set(i,tempst.action());
                		}
                		else{
                			toload.allobs.add(tempst);
                			toload.allhurdle.add(tempst.action());
                		}
                		toload.allhurdle.get(i).setRotate((saver.durations.get(i+1).toSeconds()%3)*120);
                	}
                	else if(saver.obsId.get(i)==5) {
                		Triangle temptr=new Triangle(200,saver.color);
                		
                		if(toload.allhurdle.size()>i) {
                			toload.allobs.set(i,temptr);
	                		toload.allhurdle.set(i,temptr.action());}
                		else {
                			toload.allobs.add(temptr);
                    		toload.allhurdle.add(temptr.action());
                		}
                		toload.allhurdle.get(i).setRotate((saver.durations.get(i+1).toSeconds()%3)*120);
                	}
                	else if(saver.obsId.get(i)==6) {
                		Colorswitch tempcs=new Colorswitch();
                		
                		if(toload.allhurdle.size()>i) {
	                		toload.allobs.set(i,tempcs);
	                		toload.allhurdle.set(i,tempcs.action());
                		}
                		else {
                			toload.allobs.add(tempcs);
                    		toload.allhurdle.add(tempcs.action());
                		}
//                		toload.allhurdle.get(toload.allhurdle.size()-1).setRotate((saver.durations.get(i).toSeconds()%3)*120);
                	}
                	toload.allhurdle.get(i).setTranslateY(saver.yCord.get(i+1));
                	toload.allhurdle.get(i).setRotate((saver.durations.get(i+1).toSeconds()%3)*120);

  
                	System.out.println(toload.allhurdle.size()+" , "+saver.yCord.size()+" , "+toload.allobs.size()+" , "+saver.obsId.size());
                	System.out.println("durations size:"+saver.durations.size());
                }
                System.out.println(saver.yCord);

                toload.vbox2.getChildren().add(toload.allhurdle.get(0));

                for (int i = 0; i < toload.allhurdle.size(); i++) {
        			toload.annimate(toload.allhurdle.get(i));
        		}

                System.out.println(saver.yCord.get(0));
                System.out.println("durations:"+saver.durations);
                if(saver.color.equalsIgnoreCase("0x9370dbff")) {
                    toload.bally.setcolor(Color.MEDIUMPURPLE);
                }
                else if(saver.color.equalsIgnoreCase("0xffff00ff")) {
                    toload.bally.setcolor(Color.YELLOW);
                }
                else if(saver.color.equalsIgnoreCase("0xff1493ff")) {
                    toload.bally.setcolor(Color.DEEPPINK);
                }
                else if(saver.color.equalsIgnoreCase("0x00bfffff")) {
                    toload.bally.setcolor(Color.DEEPSKYBLUE);
                }
                
                
            } 
              
            catch(IOException ex) 
            { 
                System.out.println("IOException is caught"); 
            } 
              
            catch(ClassNotFoundException ex) 
            { 
                System.out.println("ClassNotFoundException is caught"); 
            } 
    		
    		
    });
        
        BorderPane vbox2 = new BorderPane();

		/* StackPane */ vbox1=new StackPane();
        vbox1.getChildren().add(vbox2);
        vbox2.setMaxSize(500, 700);
        vbox2.setMinSize(500, 700);
        {
            vbox2.getChildren().add(iwbg);
            vbox2.getChildren().add(b);
            vbox2.getChildren().add(game1);
            vbox2.getChildren().add(game2);
            vbox2.getChildren().add(game3);
//            vbox2.getChildren().add(game4);
            
        }
        /* Scene */ sc = new Scene(vbox1, 500,700);
        stage.setResizable(true);
        stage.setScene(sc);

//        stage.setScene(sc);

        stage.show();
    }
}