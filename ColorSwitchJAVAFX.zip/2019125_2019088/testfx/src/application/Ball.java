package application;

import javafx.animation.TranslateTransition;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.util.Duration;

public class Ball extends Elements {
	private Circle ball;
	
	public Paint getcolor(int nouse) {
		return ball.getFill();
	}
	public String getcolor() {
		return ball.getFill().toString();
	}

	public  Ball(){
		ball = new Circle(360.0f, 550.0f, 10.f);
        ball.setFill(Color.DEEPPINK);
        ball.relocate(250, 450);
	}
	public Circle getBall() {
		return this.ball;
	}
	public void setcolor(Paint thy) {
		this.ball.setFill(thy);
	}

	private void translate(Node node,int x,int y,int cyclecount,int timeMilli,boolean reverse){
        TranslateTransition translate = new TranslateTransition();
        {
            translate.setDuration(Duration.millis(timeMilli));
            translate.setCycleCount(cyclecount);
            translate.setAutoReverse(reverse);
            translate.setNode(node);
        }
        translate.setByX(x);
        translate.setByY(y);
        translate.play();

    }	
    public void move(){
//    	time++;
        translate(ball,0,-60,1,100,false);

        new java.util.Timer().schedule(
                new java.util.TimerTask() {
                    @Override
                    public void run() {
                        translate(ball, 0, 720, 1, 2200, false);
                    }
                },100 );
    }
    public Group action() {
    	return new Group();
    }

}
