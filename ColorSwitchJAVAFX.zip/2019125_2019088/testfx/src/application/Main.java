package application;
import java.awt.Color;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.control.*;
import javafx.scene.effect.BlendMode;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;

public class Main extends Application{
	static SaveHighScore shs=new SaveHighScore();
    @Override
    public void start(Stage stage) {
    	Media hs = new Media(getClass().getResource("button.wav").toString());
//		Media hs= new Media("jump.mp3");
		MediaPlayer mediaPlayerHS = new MediaPlayer(hs);
		
		{
			mediaPlayerHS.setAutoPlay(false);
			mediaPlayerHS.setCycleCount(1);
		
		}
    	
    	Image bi=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\download.png");
    	ImageView pb = new ImageView(bi);
    	pb.setFitWidth(150);
    	pb.setFitHeight(150);
        Button b = new Button("",pb);
        b.setOnMouseEntered((event) -> {    
            b.setBlendMode(BlendMode.GREEN);
        });
        b.setOnMouseExited((event) -> {    
            b.setBlendMode(null);
        });
        b.setOnAction((event) -> {    // lambda expression
            //ToggleButton source = (ToggleButton) event.getSource();
        	mediaPlayerHS.play();
            enternameclass e=new enternameclass(stage);
//            Stage stage2=new Stage();
//            e.start(stage2);
            e.start();
//            stage.close();
        });
//        b.setGraphic(pb);
//        b.resize(50, 50);
        b.relocate(250, 425);
//        b.setBlendMode(BlendMode.SCREEN);
        Image tro=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\trophy.png");
    	ImageView tr = new ImageView(tro);
    	tr.setFitWidth(75);
    	tr.setFitHeight(75);
//    	tr.relocate(20, 550);
    	Button btr = new Button("",tr);
    	btr.setOnAction((event) -> {    // lambda expression
    		mediaPlayerHS.play();
    		try
            {    
                // Reading the object from a file 
        		
        		File file1=new File("highscores.txt");
                FileInputStream file = new FileInputStream(file1); 
                ObjectInputStream in = new ObjectInputStream(file); 
                  
                // Method for deserialization of object 
                shs = (SaveHighScore)in.readObject(); 
                  
                in.close(); 
                file.close(); 
                  
                System.out.println("Object has been deserialized ");   
                
            } 
              
            catch(IOException ex) 
            { 
                System.out.println("IOException is caught"); 
            } 
              
            catch(ClassNotFoundException ex) 
            { 
                System.out.println("ClassNotFoundException is caught"); 
            }
            Players high=new Players(stage,shs.allhighscores);
        });
    	RotateTransition tri=new RotateTransition(Duration.seconds(3),tr);
        tri.setByAngle(360);
        tri.setInterpolator(Interpolator.LINEAR);
       tri.setCycleCount(Timeline.INDEFINITE);
//       rot.setDelay(Duration.ZERO);
       tri.play();
        btr.setOnMouseEntered((event) -> {    
            btr.setBlendMode(BlendMode.GREEN);
        });
        btr.setOnMouseExited((event) -> {    
            btr.setBlendMode(null);
        });
        btr.relocate(50, 600);
        
        Image clo=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\close.png");
    	ImageView cl = new ImageView(clo);
    	cl.setFitWidth(75);
    	cl.setFitHeight(75);
//    	tr.relocate(20, 550);
    	RotateTransition close=new RotateTransition(Duration.seconds(3),cl);
        close.setByAngle(360);
        close.setInterpolator(Interpolator.LINEAR);
       close.setCycleCount(Timeline.INDEFINITE);
//       rot.setDelay(Duration.ZERO);
       close.play();
    	Button bcl = new Button("",cl);
        bcl.setOnMouseEntered((event) -> {    
            bcl.setBlendMode(BlendMode.RED);
        });
       bcl.setOnMouseExited((event) -> {    
            bcl.setBlendMode(null);
        });
       bcl.setOnAction((event) -> { 
    	   mediaPlayerHS.play();
    	   try { 
 			  
               // Saving of object in a file 
               FileOutputStream file = new FileOutputStream 
                                              ("highscores.txt"); 
               ObjectOutputStream out = new ObjectOutputStream 
                                              (file); 
     
               // Method for serialization of object 
               out.writeObject(shs); 
     
               out.close(); 
               file.close(); 
     
               System.out.println("highscores has been serialized"); 
           } 
     
           catch (IOException ex) { 
               System.out.println("IOException is caught"); 
           }
           stage.close();
       });
        bcl.relocate(450, 600);
        Image image=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\logo.gif");
        Image imagelg=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\lgfinal.png");
        Image obs=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\obs2.png");

        Image back=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\2131.jpg");

        ImageView iw = new ImageView(image);
        ImageView lg = new ImageView(imagelg);
        ImageView bg = new ImageView(back);
        ImageView ob1=new ImageView(obs);
        ImageView ob2=new ImageView(obs);
        ImageView ob3=new ImageView(obs);
        
        ImageView ring1=new ImageView(obs);
        ring1.setFitWidth(78);
        ring1.setFitHeight(78);
        ring1.relocate(228, 60);
        RotateTransition rotring=new RotateTransition(Duration.seconds(3),ring1);
        rotring.setByAngle(360);
        rotring.setInterpolator(Interpolator.LINEAR);
       rotring.setCycleCount(Timeline.INDEFINITE);
//       rot.setDelay(Duration.ZERO);
       rotring.play();
       
       ImageView ring2=new ImageView(obs);
       ring2.setFitWidth(78);
       ring2.setFitHeight(78);
       ring2.relocate(340, 60);
       RotateTransition rotring2=new RotateTransition(Duration.seconds(3),ring2);
       rotring2.setByAngle(360);
       rotring2.setInterpolator(Interpolator.LINEAR);
      rotring2.setCycleCount(Timeline.INDEFINITE);
//      rot.setDelay(Duration.ZERO);
      rotring2.play();
        
        ob3.setFitWidth(250);
        ob3.setFitHeight(250);
        ob3.relocate(125,300);
        ob2.setFitWidth(350);
        ob2.setFitHeight(350);
        ob2.relocate(75,250);
        ob2.setRotate(180);
        ob1.setFitWidth(450);
        ob1.setFitHeight(450);
        ob1.relocate(25,200);
        lg.setFitWidth(375);
        lg.setFitHeight(272.625);
        lg.relocate(130, 0);
        bg.setFitHeight(700);
        bg.setFitWidth(500);
        iw.setFitHeight(131.25);
        iw.setFitWidth(112.5);
        iw.relocate(40, 70);
        BorderPane vbox2 = new BorderPane();
//        vbox2.setBackground(new Background(new BackgroundFill(Color.BLACK, new CornerRadii(0), Insets.EMPTY)));
        RotateTransition rot=new RotateTransition(Duration.seconds(3),ob1);
        rot.setByAngle(360);
        rot.setInterpolator(Interpolator.LINEAR);
       rot.setCycleCount(Timeline.INDEFINITE);
//       rot.setDelay(Duration.ZERO);
       rot.play();
        
       RotateTransition rot2=new RotateTransition(Duration.seconds(3),ob2);
       rot2.setByAngle(-360);
       rot2.setInterpolator(Interpolator.LINEAR);
      rot2.setCycleCount(Timeline.INDEFINITE);
//      rot2.setDelay(Duration.ZERO);
      rot2.play();
      
      RotateTransition rot3=new RotateTransition(Duration.seconds(3),ob3);
      rot3.setByAngle(360);
     rot3.setCycleCount(Timeline.INDEFINITE);
     rot3.setInterpolator(Interpolator.LINEAR);
//     rot3.setDelay(Duration.ZERO);
     rot3.play();
      
        vbox2.setMaxSize(500, 700);
        vbox2.setMinSize(500, 700);
        //        vbox2.setBackground(new Background());
        {
        	vbox2.getChildren().add(bg);
        	vbox2.getChildren().add(lg);
            vbox2.getChildren().add(iw);
            vbox2.getChildren().add(ob1);
            vbox2.getChildren().add(ob2);
            vbox2.getChildren().add(ob3);
            vbox2.getChildren().add(b);
            vbox2.getChildren().add(ring1);
            vbox2.getChildren().add(ring2);
            vbox2.getChildren().add(btr);
            vbox2.getChildren().add(bcl);
        }
        

//        StackPane r = new StackPane(); 

        
        Scene sc = new Scene(vbox2, 500,650); 
        stage.setResizable(true);

        stage.setScene(sc); 
  
        stage.show(); 

        stage.setTitle("Color Switch");
    }

    public static void main(String[] args) {
        launch();
    }
}