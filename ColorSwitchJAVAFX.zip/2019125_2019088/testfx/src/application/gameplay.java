package application;

import javafx.geometry.Pos;
import javafx.scene.paint.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.RotateTransition;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import javafx.scene.control.*;
import javafx.scene.effect.BlendMode;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.text.Text;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

public class gameplay implements Serializable{
	public int savecounter=0;
	public volatile BorderPane vbox2;
	public String playername;
	public volatile Boolean continued=false;
	public volatile Stage stage;
	public volatile ArrayList<Group> allhurdle=new ArrayList<Group>(4);
	public volatile ArrayList<Obstacle> allobs=new ArrayList<Obstacle>(4);
	public volatile ArrayList<RotateTransition> rotations=new ArrayList<RotateTransition>(4);
	public volatile Timeline timeline3;
	public volatile Timeline timeline4;
	volatile Ball bally;
	volatile Boolean starc=false;
	volatile int Score=0;
	volatile Text t;
//	double Oby=5;
	
	

	public gameplay(Stage stage,String playername) {
		this.stage = stage;
		this.playername=playername;
	}
	public RotateTransition annimate(Group box) {
		RotateTransition boxy=new RotateTransition(Duration.seconds(3),box);
        boxy.setByAngle(360);
       boxy.setCycleCount(Timeline.INDEFINITE);
       boxy.setInterpolator(Interpolator.LINEAR);
//       rot3.setDelay(Duration.ZERO);
       boxy.play();
       return boxy;
	}
	public void translate(Group node,int x,int y,int cyclecount,int timeMilli,boolean reverse){
        TranslateTransition translate = new TranslateTransition();
        {
            translate.setDuration(Duration.millis(timeMilli));
            translate.setCycleCount(cyclecount);
            translate.setAutoReverse(reverse);
            translate.setNode(node);
        }
        translate.setByX(x);
        translate.setByY(y);
        translate.play();

	}
	
	public void Worldmaker(int size) {
//		allhurdle.remove(0);
//		Group toadd2=new Circular().action();
//		toadd2.relocate(150,-150);
//		annimate(toadd2);
//		allhurdle.add(toadd2);
//		Group toadd=new Square(200).action();
//		toadd.relocate(150,-150);
//		annimate(toadd);
//		allhurdle.add(toadd);
		allhurdle.remove(0);
		allobs.remove(0);
		starc=false;
        Random r=new Random();
        int rint=r.nextInt(6);
        if(rint==0) {
        	Circular tempc=new Circular();
            Group toadd2 = tempc.action();
//            toadd2.relocate(150, -150);
            tempc.Position[0]=150;
            tempc.Position[1]=-150;
            rotations.add(annimate(toadd2));
            allhurdle.add(toadd2);
            allobs.add(tempc);
        }
        if(rint==1) {
        	Square temps=new Square(200);
            Group toadd = temps.action();
//            toadd.relocate(150, -150);
            temps.Position[0]=150;
            temps.Position[1]=-150;
            rotations.add(annimate(toadd));
            allhurdle.add(toadd);
            allobs.add(temps);
        }
        if(rint==2) {
        	Plus tempp=new Plus(200);
            Group toadd4 = tempp.action();
//            toadd4.relocate(150, -150);
            tempp.Position[0]=150;
            tempp.Position[1]=-150;
            rotations.add(annimate(toadd4));
            allhurdle.add(toadd4);
            allobs.add(tempp);
        }
        if(rint==3) {
        	Triangle temptr=new Triangle(200,bally.getcolor());
            Group toadd3 = temptr.action();
//            toadd3.relocate(210, -150);
            temptr.Position[0]=210;
            temptr.Position[1]=-150;
            rotations.add(annimate(toadd3));
            allhurdle.add(toadd3);
            allobs.add(temptr);
       }
        if(rint==4) {
        	Starobs tempst=new Starobs(200);
            Group toadd = tempst.action();
//            toadd.relocate(175, -150);
            tempst.Position[0]=175;
            tempst.Position[1]=-150;
            rotations.add(annimate(toadd));
            allhurdle.add(toadd);
            allobs.add(tempst);
        }
        if(rint==5) {
        	Colorswitch tempcs=new Colorswitch();
    		Group toaddc=tempcs.action() ;
////    		toaddc.relocate(220, -150);
    		tempcs.Position[1]=-150;
    		rotations.add(annimate(toaddc));
    		allhurdle.add(toaddc);
    		allobs.add(tempcs);
        }
    }
	
	

	public void start() {
		/* Ball */bally=new Ball();
		
//		Colorswitch tempcs=new Colorswitch();
//		Group toaddc=tempcs.action() ;
//////		toaddc.relocate(220, -150);
//		tempcs.Position[1]=-150;
//		rotations.add(annimate(toaddc));
//		allhurdle.add(toaddc);
//		allobs.add(tempcs);
		
		
		Square temps=new Square(200);
		Group toadd2=temps.action();
////		toadd2.relocate(150,-150);
		temps.Position[1]=-150;
		rotations.add(annimate(toadd2));
		allhurdle.add(toadd2);
		allobs.add(temps);
		
		Circular tempc=new Circular();
		Group toadd=tempc.action();
//		toadd.relocate(150,-150);
		tempc.Position[1]=-150;
		rotations.add(annimate(toadd));
		allhurdle.add(toadd);
		allobs.add(tempc);
		
//		Starobs tempst=new Starobs(200);
//		Group toadd3=tempst.action();
////		toadd3.relocate(175,-150);
//		tempst.Position[1]=-150;
//		rotations.add(annimate(toadd3));
//		allhurdle.add(toadd3);
//		allobs.add(tempst);
		
//		Plus tempp=new Plus(200);
//		Group toadd4=tempp.action();
////		toadd4.relocate(175,-150);
//		tempp.Position[1]=-150;
//		rotations.add(annimate(toadd4));
//		allhurdle.add(toadd4);
//		allobs.add(tempp);
		
		Colorswitch tempcs=new Colorswitch();
		Group toaddc=tempcs.action() ;
////		toaddc.relocate(220, -150);
		tempcs.Position[1]=-150;
		rotations.add(annimate(toaddc));
		allhurdle.add(toaddc);
		allobs.add(tempcs);
		
		Triangle temptr=new Triangle(200,bally.getcolor());
        Group toadd3 = temptr.action();
//        toadd3.relocate(210, -150);
        temptr.Position[0]=210;
        temptr.Position[1]=-150;
        rotations.add(annimate(toadd3));
        allhurdle.add(toadd3);
        allobs.add(temptr);
//		allhurdle.add(new Circular().action());
		
//		for (int i = 0; i < allhurdle.size(); i++) {
//			annimate(allhurdle.get(i));
//		}
		
//		allhurdle.add(new Square(300).action());
//		Circle ball=bally.getBall();
				
//		Circle ball = new Circle(20, Color.YELLOW);
//		ball.relocate(240, 550);
		
		
		
		Image imagebg = new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\2131.jpg");
		ImageView iwbg = new ImageView(imagebg);
		iwbg.setFitHeight(700);
		iwbg.setFitWidth(500);

//		Obstacle ci=new Circular();
//		Square ci=new Square(200);
//		box.setSize(150);
//		Group circle=ci.action();
//		ci.annimate(circle);
//		circle.relocate(100, 125);

		Image imagepause = new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\pausy.png");
		Media hs = new Media(getClass().getResource("button.wav").toString());
//		Media hs= new Media("jump.mp3");
		MediaPlayer mediaPlayerHS = new MediaPlayer(hs);
		
		{
			mediaPlayerHS.setAutoPlay(false);
			mediaPlayerHS.setCycleCount(1);
		
		}
		ImageView pause = new ImageView(imagepause);
		Button bp = new Button("", pause);
		bp.relocate(50, 75);

		bp.setOnMouseEntered((event) -> {
			bp.setBlendMode(BlendMode.RED);
		});
		bp.setOnMouseExited((event) -> {
			bp.setBlendMode(null);
		});
		bp.setOnAction((event) -> {
//			pause_exitmenu e = new pause_exitmenu(stage);
//			e.start();
			mediaPlayerHS.play();
			for(int i=0;i<allhurdle.size();i++) {
				stopanimate(allhurdle.get(i));
			}
			timeline3.pause();
			timeline4.pause();
			Paint tempy=bally.getcolor(0);
			Ball newball=new Ball();
			newball.Position[0]=bally.Position[0];
			newball.Position[1]=bally.Position[1];
			vbox2.getChildren().set(2,newball.getBall());
			bally=newball;
			bally.setcolor(tempy);
			vbox2.getChildren().add(pausemenu());
//			ci.rotg.pause();
		});

		pause.setFitHeight(100);
		pause.setFitWidth(100);
//        pause.relocate(50,50);
		
		
		
		
		
		
//code for obstacle-ball interaction starts here		
		/* Timeline */ timeline4 = new Timeline(

                new KeyFrame(Duration.millis(100),
                        new EventHandler<ActionEvent>() {
                            @Override
                            public void handle(ActionEvent event) {
//                            	System.out.println(bally.getBall().getBoundsInParent().getCenterY());
                            	bally.Position[0]=bally.getBall().getBoundsInParent().getCenterX();
                            	bally.Position[1]=bally.getBall().getBoundsInParent().getCenterY();
                            	
                            	if (allobs.get(0) instanceof Square) {
                            		((Square)allobs.get(0)).Position[0]=allhurdle.get(0).getBoundsInParent().getCenterX();
                                    ((Square)allobs.get(0)).Position[1]=allhurdle.get(0).getBoundsInParent().getCenterY();
//                                    ((Square)allobs.get(0)).duration=allhurdle.get(0).getLayoutY();
                                }
                                else if (allobs.get(0) instanceof Circular) {
                                	((Circular)allobs.get(0)).Position[0]=allhurdle.get(0).getBoundsInParent().getCenterX();
                                    ((Circular)allobs.get(0)).Position[1]=allhurdle.get(0).getBoundsInParent().getCenterY();
                                }
                                else if (allobs.get(0) instanceof Plus) {
                                	((Plus)allobs.get(0)).Position[0]=allhurdle.get(0).getBoundsInParent().getCenterX();
                                    ((Plus)allobs.get(0)).Position[1]=allhurdle.get(0).getBoundsInParent().getCenterY();
                                }
                                else if (allobs.get(0) instanceof Starobs) {
                                	((Starobs)allobs.get(0)).Position[0]=allhurdle.get(0).getBoundsInParent().getCenterX();
                                    ((Starobs)allobs.get(0)).Position[1]=allhurdle.get(0).getBoundsInParent().getCenterY();
                                }
                                else if (allobs.get(0) instanceof Triangle) {
                                	((Triangle)allobs.get(0)).Position[0]=allhurdle.get(0).getBoundsInParent().getCenterX();
                                    ((Triangle)allobs.get(0)).Position[1]=allhurdle.get(0).getBoundsInParent().getCenterY();
                                }
                                else if (allobs.get(0) instanceof Colorswitch) {
                                	((Colorswitch)allobs.get(0)).Position[0]=allhurdle.get(0).getBoundsInParent().getCenterX();
                                    ((Colorswitch)allobs.get(0)).Position[1]=allhurdle.get(0).getBoundsInParent().getCenterY();
                                }
                            	
		ArrayList<Shape> intersections=new ArrayList<Shape>();
		ArrayList<String> colors=new ArrayList<String>();
		for(int i=0;i<allhurdle.get(0).getChildren().size();i++) {
//			Shape tempy=(Shape)circle.getChildren().get(i);
//			allhurdle.get(0)=allhurdle.get(0).getLayoutY();
			if(!starc&&allhurdle.get(0).getChildren().size()!=1) {
			if(i<allhurdle.get(0).getChildren().size()-1) {
			colors.add(((Shape)allhurdle.get(0).getChildren().get(i)).getStroke().toString());
			intersections.add(Shape.intersect(bally.getBall(), (Shape)allhurdle.get(0).getChildren().get(i)));}
			
			else {
				Shape intersectstar=Shape.intersect(bally.getBall(), (Shape)allhurdle.get(0).getChildren().get(i));
				if(intersectstar.getBoundsInLocal().getWidth() != -1) {
					System.out.println("scored");
					Score++;
					if(Main.shs.allhighscores.containsKey(playername)&&Main.shs.allhighscores.get(playername)<Score) {
						Main.shs.allhighscores.put(playername,Score);
						System.out.println("Score updated");
					}
					else if(!Main.shs.allhighscores.containsKey(playername)) {
						Main.shs.allhighscores.put(playername,Score);
						System.out.println("Score updated");

					}
					t.setText(""+Score);
					allhurdle.get(0).getChildren().remove(i);
					i--;
					starc=true;
					}
				}
			}
			else {
				colors.add(((Shape)allhurdle.get(0).getChildren().get(i)).getStroke().toString());
				intersections.add(Shape.intersect(bally.getBall(), (Shape)allhurdle.get(0).getChildren().get(i)));
				if(colors.get(i).equals(Color.BLACK.toString())&&intersections.get(i).getBoundsInLocal().getWidth() != -1) {
            	Random r=new Random();
            	Paint tempy=bally.getcolor(0);
            	while(bally.getcolor(1).equals(tempy))
            	{
            		int rint=r.nextInt(4);
            	
	            	if(rint==0) {
	            		bally.setcolor(Color.DEEPPINK);
	            	}
	            	else if(rint==1) {
	            		bally.setcolor(Color.DEEPSKYBLUE);
	            	}
	            	else if(rint==2) {
	            		bally.setcolor(Color.YELLOW);
	            	}
	            	else if(rint==3){
	            		bally.setcolor(Color.MEDIUMPURPLE);
	            	}
            	}
        	}
            	
			}
//			System.out.println(((Shape)circle.getChildren().get(i)).getStroke().toString());
		}
		for(int i=0;i<intersections.size();i++) {
			if(intersections.get(i).getBoundsInLocal().getWidth() != -1 || bally.Position[1]>=700) {
				if(!(bally.getcolor().equalsIgnoreCase(colors.get(i))||colors.get(i).equals(Color.BLACK.toString()))) {
//					System.out.println("collided");
					if(Score>=3&&!continued) {
						Score-=3;
						try
			            {    
							for(int it=0;it<allhurdle.size();it++) {
								stopanimate(allhurdle.get(it));
							}
							timeline3.pause();
							timeline4.pause();
							Paint tempy=bally.getcolor(0);
							Ball newball=new Ball();
							newball.Position[0]=bally.Position[0];
							newball.Position[1]=bally.Position[1]+150;
							vbox2.getChildren().set(2,newball.getBall());
							bally=newball;
							bally.setcolor(tempy);
			        		savegame saver=new savegame(rotations,allobs,bally,"vasu",Score);
			        		File file1=new File("continue.txt");
			                //Saving of object in a file 
			                FileOutputStream file = new FileOutputStream(file1); 
			                ObjectOutputStream out = new ObjectOutputStream(file); 
			                // Method for serialization of object 
			                out.writeObject(saver); 
			                  
			                out.close(); 
			                file.close(); 
			                  
			                System.out.println("Object has been serialized"); 
			                continued=true;
			      
			            } 
			              
			            catch(IOException ex) 
			            { 
			                System.out.println("IOException is caught"); 
			            }
						hit_exitmenu torun=new hit_exitmenu(stage,playername);
						torun.start();
						
					}
					else if(!continued){
						playmenu e=new playmenu(stage,playername);
//			            Stage stage3=new Stage();
						continued=true;
			            e.start();
					}
//					hit_exitmenu e=new hit_exitmenu(stage);
					
//		            Stage stage2=new Stage();
//		            e.start();
				}
			}
		}
                            }
                }

        ));
{
    timeline4.setCycleCount(Timeline.INDEFINITE);
    timeline4.play();
}
//Node temp=((Node)(bally.getBall()));
//System.out.println(((Shape)temp).getFill().toString());
//code for obstacle-ball interaction ends here
        
		StackPane vbox1 = new StackPane();
		/* BorderPane */ vbox2 = new BorderPane();

		vbox1.getChildren().add(vbox2);
		Scene sc = new Scene(vbox1, 500, 650);
		stage.setResizable(true);

		stage.setScene(sc);

		stage.show();
		sc.setOnKeyPressed(f -> {
            switch (f.getCode()) {
                case A:
//                	mediaPlayerHS.play();
                    bally.move();
//                	System.out.println("just pressed space");


                    break;
            }
        });
		
		/* Timeline */timeline3=new Timeline(
				new KeyFrame(Duration.millis(100),
                        new EventHandler<ActionEvent>() {
                            @Override
                            public void handle(ActionEvent event) {
                            	if(bally.Position[1]<400) {
//                            		System.out.println("hello");
                            		translate(allhurdle.get(0),0,25,1,100,false);
//                            		allhurdle.get(0)
                            	}
                            	if(allhurdle.get(0).getBoundsInParent().getCenterY()>700) {
                            		Worldmaker(200);
                            		vbox2.getChildren().remove(vbox2.getChildren().size()-1,vbox2.getChildren().size());
                            		System.out.println("removed");
                            		vbox2.getChildren().add(allhurdle.get(0));
                            	}
//                            	if(allhurdle.get(0).getBoundsInParent().getCenterY()>700) {
//                            		allhurdle.remove(0);
//                            	}
                            }
                }

        ));
		{
		    timeline3.setCycleCount(Timeline.INDEFINITE);
		    timeline3.play();
		}
		/* Text */ t = new Text (""+Score);
		t.setFont(Font.font("Verdana", FontWeight.BOLD, 70));
		t.setFill(Color.WHITE);
		t.relocate(50, 600);
		vbox2.setMaxSize(500, 700);
		vbox2.setMinSize(500, 700);
		{
			vbox2.getChildren().add(iwbg);
			vbox2.getChildren().add(bp);
			vbox2.getChildren().add(bally.getBall());
			vbox2.getChildren().add(t);
//			vbox2.getChildren().add(circle);
			vbox2.getChildren().add(allhurdle.get(0));
		}
		
	}
	Group pausemenu() {
		Group screen= new Group();
		screen.setBlendMode(BlendMode.BLUE);

		Media hs = new Media(getClass().getResource("button.wav").toString());
//		Media hs= new Media("jump.mp3");
		MediaPlayer mediaPlayerHS = new MediaPlayer(hs);
		
		{
			mediaPlayerHS.setAutoPlay(false);
			mediaPlayerHS.setCycleCount(1);
		
		}
     
        Image image4=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\restart.png");
        ImageView pb1=new ImageView(image4);
        pb1.setFitHeight(100);
        pb1.setFitWidth(250);
//        //pb.relocate(20, 100);
        Button brestart = new Button("",pb1);
        vbox2.setEffect(new GaussianBlur());
        pause_exitmenu p = new pause_exitmenu(stage,playername);
        Stage popupStage = new Stage(StageStyle.TRANSPARENT);
        {
            popupStage.initOwner(stage);
//            popupStage.initModality(Modality.APPLICATION_MODAL);
            p.start();
            popupStage.setScene(p.sc);
            popupStage.show();
        }

        p.bresume.setOnMouseClicked(g -> {
        	mediaPlayerHS.play();
        	for(int i=0;i<allhurdle.size();i++) {
				annimate(allhurdle.get(i));
			}
        	timeline3.play();
        	timeline4.play();
        	bally.getBall().relocate(bally.Position[0], bally.Position[1]);
            vbox2.setEffect(null);
        	vbox2.getChildren().remove(vbox2.getChildren().size()-1);
            popupStage.hide();
        });
        p.bsave.setOnMouseClicked((event) -> {    // lambda expression
            //ToggleButton source = (ToggleButton) event.getSource();
        	mediaPlayerHS.play();
        	for(int savecounter1=1;savecounter1<=3;savecounter1++) {
        		
        		
        		File file1=new File(playername+""+(savecounter1)+".txt");
        		if(!file1.exists()) {
//        			file1.createNewFile();
        			savecounter++;
        		try
        		{ 
        			file1.createNewFile();
        		savegame saver=new savegame(rotations,allobs,bally,playername,Score);
//        		File file1=new File(playername+""+(savecounter)+".txt");
                //Saving of object in a file 
                FileOutputStream file = new FileOutputStream(file1); 
                ObjectOutputStream out = new ObjectOutputStream(file); 
                // Method for serialization of object 
                out.writeObject(saver); 
                  
                out.close(); 
                file.close(); 
                  
                System.out.println("Object has been serialized"); 
      
            } 
              
            catch(IOException ex) 
            { 
                System.out.println("IOException is caught"); 
            }
        		break;
        	} 
        		
        	 	
        	}
        	
        	
        });

        p.brestart.setOnMouseClicked((event) -> {    // lambda expression
            //ToggleButton source = (ToggleButton) event.getSource();
        	mediaPlayerHS.play();
                vbox2.setEffect(null);
            	vbox2.getChildren().remove(vbox2.getChildren().size()-1);
                popupStage.hide();
                gameplay e=new gameplay(stage,playername);
//              Stage stage2=new Stage();
              e.start();
            });

        return screen;
	}
//	Group hitmenu() {
//		Group screen= new Group();
//		screen.setBlendMode(BlendMode.BLUE);
//        vbox2.setEffect(new GaussianBlur());
//        hit_exitmenu p = new hit_exitmenu(stage);
//        Stage popupStage = new Stage(StageStyle.TRANSPARENT);
//        {
//            popupStage.initOwner(stage);
////            popupStage.initModality(Modality.APPLICATION_MODAL);
//            p.start();
//            popupStage.setScene(p.sc);
//            popupStage.show();
//        }
//
//        p.bresume.setOnMouseClicked(g -> {
////        	for(int i=0;i<allhurdle.size();i++) {
////				annimate(allhurdle.get(i));
////			}
////        	bally.getBall().relocate(bally.Position[0], bally.Position[1]+100);
////        	timeline3.play();
////        	timeline4.play();
////            vbox2.setEffect(null);
////        	vbox2.getChildren().remove(vbox2.getChildren().size()-1);
////            popupStage.hide();
//            Score-=3;
//        });
//        
//        p.brestart.setOnMouseClicked((event) -> {    // lambda expression
//            //ToggleButton source = (ToggleButton) event.getSource();
//                vbox2.setEffect(null);
//            	vbox2.getChildren().remove(vbox2.getChildren().size()-1);
//                popupStage.hide();
//                gameplay e=new gameplay(stage);
////              Stage stage2=new Stage();
//              e.start();
//            });
//
//        return screen;
//	}
	public void stopanimate(Group xy) {
//		annimate(xy).stop();
//		System.out.println("pausing");
		RotateTransition boxy=new RotateTransition(Duration.seconds(3),xy);
        boxy.setByAngle(0);
       boxy.setCycleCount(Timeline.INDEFINITE);
       boxy.setInterpolator(Interpolator.LINEAR);
//       rot3.setDelay(Duration.ZERO);
       boxy.play();
	}
}