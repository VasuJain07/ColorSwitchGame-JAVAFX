package application;

import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.animation.Timeline;
import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;
import javafx.util.Duration;

public class Circular extends Elements implements Obstacle{
	private float Speed;
	private float Size;
	public RotateTransition rotg;
	@Override
	public float getSpeed() {
		return Speed;
	}
	@Override
	public void setSpeed(float Speed) {
		this.Speed=Speed;
	}
	@Override
	public Group action() { 
	Arc arcb = new Arc();
	arcb.setCenterX(112.5);
	arcb.setCenterY(87.5);
	arcb.setStartAngle(0);
	arcb.setLength(90);
	arcb.setRadiusX(100);
	arcb.setRadiusY(100);
	arcb.setFill(Color.TRANSPARENT);
	arcb.setStroke(Color.DEEPSKYBLUE);
	arcb.setStrokeWidth(25);
	arcb.setType(ArcType.OPEN);
	arcb.setTranslateX(100);
	arcb.setTranslateY(100);

	Arc arcy = new Arc();
	arcy.setCenterX(112.5);
	arcy.setCenterY(100);
	arcy.setStartAngle(270);
	arcy.setLength(90);
	arcy.setRadiusX(100);
	arcy.setRadiusY(100);
	arcy.setFill(Color.TRANSPARENT);
	arcy.setStroke(Color.YELLOW);
	arcy.setStrokeWidth(25);
	arcy.setType(ArcType.OPEN);
	arcy.setTranslateX(100);
	arcy.setTranslateY(100);

	Arc arcp = new Arc();
	arcp.setCenterX(100);
	arcp.setCenterY(87.5);
	arcp.setStartAngle(90);
	arcp.setLength(90);
	arcp.setRadiusX(100);
	arcp.setRadiusY(100);
	arcp.setFill(Color.TRANSPARENT);
	arcp.setStroke(Color.DEEPPINK);
	arcp.setStrokeWidth(25);
	arcp.setType(ArcType.OPEN);
	arcp.setTranslateX(100);
	arcp.setTranslateY(100);

	Arc arcpu = new Arc();
	arcpu.setCenterX(100);
	arcpu.setCenterY(100);
	arcpu.setStartAngle(180);
	arcpu.setLength(90);
	arcpu.setRadiusX(100);
	arcpu.setRadiusY(100);
	arcpu.setFill(Color.TRANSPARENT);
	arcpu.setStroke(Color.MEDIUMPURPLE);
	arcpu.setStrokeWidth(25);
	arcpu.setType(ArcType.OPEN);
	arcpu.setTranslateX(100);
	arcpu.setTranslateY(100);
	
	Circle starb=new Circle(30);
	 starb.relocate(175, 160);
	 
	 Image image = new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\star.png");
      ImagePattern imagePattern = new ImagePattern(image);
       starb.setFill(imagePattern);

	Group cir= new Group(arcb, arcp,  arcpu, arcy,starb);
//	RotateTransition rotg = new RotateTransition(Duration.seconds(2.2),cir);
//	rotg.setByAngle(360);
//	rotg.setCycleCount(Timeline.INDEFINITE);
//	rotg.setInterpolator(Interpolator.LINEAR);
////   rot3.setDelay(Duration.ZERO);
//	rotg.play();
	cir.relocate(150,-150);
	return cir;
	}
	@Override
	public void setSize(float size) {
		this.Size=size;
	}
	@Override
	public float getSize() {
		return this.Size;
	}
	@Override
	public void annimate(Group some) {
		rotg = new RotateTransition(Duration.seconds(2.2),some);
		rotg.setByAngle(360);
		rotg.setCycleCount(Timeline.INDEFINITE);
		rotg.setInterpolator(Interpolator.LINEAR);
	//   rot3.setDelay(Duration.ZERO);
		rotg.play();
	}
}