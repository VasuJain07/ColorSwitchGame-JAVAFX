package application;

import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.animation.Timeline;
import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.util.Duration;

public class Plus extends Elements implements Obstacle {
    private float Speed;
    private float Size;
    public RotateTransition boxy;
    public Plus(int newsize)
    {
        this.Size=newsize;
    }
    @Override
    public float getSpeed() {
        return Speed;
    }
    @Override
    public void setSpeed(float Speed) {
        this.Speed=Speed;
    }
    @Override
    public Group action() {
        Line linep=new Line(0,0,Size,0);
        linep.setStrokeWidth(30);
        linep.setStroke(Color.MEDIUMPURPLE);
        linep.relocate(0,2*Size);

        Line liney=new Line(0,0,0,Size);
        liney.setStrokeWidth(30);
        liney.setStroke(Color.YELLOW);
        liney.relocate(Size,Size);

        Line linepi=new Line(0,0,Size,0);
        linepi.setStrokeWidth(30);
        linepi.setStroke(Color.DEEPPINK);
        linepi.relocate(Size,2*Size);

        Line lineb=new Line(0,0,0,Size);
        lineb.setStrokeWidth(30);
        lineb.setStroke(Color.DEEPSKYBLUE);
        lineb.relocate(Size,2*Size);
        Circle starb=new Circle(30);
		 starb.relocate(3*Size/2-15, 3*Size/2-15);
		 
		 Image image = new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\star.png");
	       ImagePattern imagePattern = new ImagePattern(image);
	        starb.setFill(imagePattern);
        Group box=new Group(linep,liney,linepi,lineb,starb);
        RotateTransition boxy=new RotateTransition(Duration.seconds(3),box);
        boxy.setByAngle(360);
        boxy.setCycleCount(Timeline.INDEFINITE);
        boxy.setInterpolator(Interpolator.LINEAR);
//       rot3.setDelay(Duration.ZERO);
        boxy.play();
        box.relocate(150, -150);
        return box;
    }
    @Override
    public void setSize(float size) {
        this.Size=size;
    }
    @Override
    public float getSize() {
        return this.Size;
    }
    public void annimate(Group box) {
        boxy=new RotateTransition(Duration.seconds(3),box);
        boxy.setByAngle(360);
        boxy.setCycleCount(Timeline.INDEFINITE);
        boxy.setInterpolator(Interpolator.LINEAR);
//       rot3.setDelay(Duration.ZERO);
        boxy.play();
    }

}