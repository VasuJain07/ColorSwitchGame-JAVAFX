package application;

import java.io.Serializable;
import java.util.HashMap;

public class SaveHighScore implements Serializable{
	HashMap<String,Integer> allhighscores=new HashMap<String,Integer>();
	
}
