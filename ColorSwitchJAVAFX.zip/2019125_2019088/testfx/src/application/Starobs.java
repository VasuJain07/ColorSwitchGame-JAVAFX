package application;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.util.Duration;
public class Starobs extends Elements implements Obstacle{
    private float Speed;
    private float Size;
    public RotateTransition boxy;
    public Starobs(float s)
    {
        this.Size=s;
    }
    @Override
    public float getSpeed() {
        return Speed;
    }
    @Override
    public void setSpeed(float Speed) {
        this.Speed=Speed;
    }
    @Override
    public Group action() {
        Line line1=new Line(0,0,(int)Size/2,(int)Size/2);
        line1.setStrokeWidth(20);
        line1.setStroke(Color.MEDIUMPURPLE);
        line1.relocate(Size,Size);
        Line line2=new Line((int)Size/2,0,0,(int)Size/2);
        line2.setStrokeWidth(20);
        line2.setStroke(Color.YELLOW);
        line2.relocate(Size+(int)Size/2,Size);
        Line line3=new Line(0,0,0,Math.sqrt(2)*(int)Size/2);
        line3.setStrokeWidth(20);
        line3.setStroke(Color.MEDIUMPURPLE);
        line3.relocate(Size+(int)Size/2,Size/Math.sqrt(1.8));
        Line line4=new Line(0,0,0,Math.sqrt(2)*(int)Size/2);
        line4.setStrokeWidth(20);
        line4.setStroke(Color.DEEPPINK);
        line4.relocate(Size+(int)Size/2,Size+(int)Size/2);
        Line line5=new Line(0,0,(int)Size/2,(int)Size/2);
        line5.setStrokeWidth(20);
        line5.setStroke(Color.DEEPPINK);
        line5.relocate(Size+(int)Size/2,Size+(int)Size/2);
        Line line6=new Line((int)Size/2,0,0,(int)Size/2);
        line6.setStrokeWidth(20);
        line6.setStroke(Color.DEEPSKYBLUE);
        line6.relocate(Size,Size+(int)Size/2);
        Line line7=new Line(0,0,Math.sqrt(2)*(int)Size/2,0);
        line7.setStrokeWidth(20);
        line7.setStroke(Color.YELLOW);
        line7.relocate(Size+(int)Size/2,Size+(int)Size/2);
        Line line8=new Line(0,0,Math.sqrt(2)*(int)Size/2,0);
        line8.setStrokeWidth(20);
        line8.setStroke(Color.DEEPSKYBLUE);
        line8.relocate(Size+(int)Size/2-Math.sqrt(2)*(int)Size/2,Size+(int)Size/2);
        Circle starb=new Circle(30);
		 starb.relocate(3*Size/2-15, 2*Size+100);
		 
		 Image image = new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\star.png");
	       ImagePattern imagePattern = new ImagePattern(image);
	        starb.setFill(imagePattern);
        Group box=new Group(line1,line2,line3,line4,line5,line6,line7,line8,starb);
        box.relocate(175, -150);
        return box;
    }
    @Override
    public void setSize(float size) {
        this.Size=size;
    }
    @Override
    public float getSize() {
        return this.Size;
    }
    public void annimate(Group box) {
        boxy=new RotateTransition(Duration.seconds(3),box);
        boxy.setByAngle(360);
        boxy.setCycleCount(Timeline.INDEFINITE);
        boxy.setInterpolator(Interpolator.LINEAR);
//       rot3.setDelay(Duration.ZERO);
        boxy.play();
    }
}
