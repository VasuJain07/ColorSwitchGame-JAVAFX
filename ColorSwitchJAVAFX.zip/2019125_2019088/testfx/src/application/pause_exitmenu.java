package application;
import javafx.geometry.Pos;
import javafx.scene.paint.*;
import java.io.FileInputStream;
import javafx.animation.RotateTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.control.*;
import javafx.scene.effect.BlendMode;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.text.Text;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

public class pause_exitmenu {
	public Scene sc;
	Button bresume=new Button();
	Button brestart=new Button();
	Button bsave=new Button();
	public Stage stage; 
	public String playername;
	StackPane vbox1;
	public pause_exitmenu(Stage stage,String playername) {
		this.stage=stage;
//		stage.setScene(sc);
		this.start();
//		sc=new Scene(vbox1,500,500);
	}
    public void start()
    {
    	Media hs = new Media(getClass().getResource("button.wav").toString());
//		Media hs= new Media("jump.mp3");
		MediaPlayer mediaPlayerHS = new MediaPlayer(hs);
		
		{
			mediaPlayerHS.setAutoPlay(false);
			mediaPlayerHS.setCycleCount(1);
		
		}
//        Image imagebg=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\2131.jpg");
        Image imagebg=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\black2.jpg");

        ImageView iwbg=new ImageView(imagebg);
        iwbg.setFitHeight(700);
        iwbg.setFitWidth(500);

        Image image3=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\resume.png");
        ImageView pb=new ImageView(image3);
        pb.setFitHeight(100);
        pb.setFitWidth(250);
        //pb.relocate(20, 100);
		/* Button */ bresume = new Button("",pb);
        bresume.relocate(250, 250);
        bresume.setOnMouseEntered((event) -> {    
            bresume.setBlendMode(BlendMode.BLUE);
        });
        bresume.setOnMouseExited((event) -> {    
            bresume.setBlendMode(null);
        });
//        bresume.setOnAction((event) -> {    // lambda expression
//            //ToggleButton source = (ToggleButton) event.getSource();
//            gameplay e=new gameplay(stage);
//
//            e.start();
////            stage.close();
//        });

        Image image4=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\restart.png");
        ImageView pb1=new ImageView(image4);
        pb1.setFitHeight(100);
        pb1.setFitWidth(250);
        //pb.relocate(20, 100);
		/* Button */brestart = new Button("",pb1);
        brestart.relocate(250, 350);
        brestart.setOnMouseEntered((event) -> {    
            brestart.setBlendMode(BlendMode.BLUE);
        });
        brestart.setOnMouseExited((event) -> {    
            brestart.setBlendMode(null);
        });
//        brestart.setOnAction((event) -> {    // lambda expression
//            //ToggleButton source = (ToggleButton) event.getSource();
//            gameplay e=new gameplay(stage);
////            Stage stage2=new Stage();
//            e.start();
////            stage.close();
//        });

        Image image5=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\save.png");
        ImageView pb2=new ImageView(image5);
        pb2.setFitHeight(100);
        pb2.setFitWidth(250);
        //pb.relocate(20, 100);
		/* Button */ bsave = new Button("",pb2);
        bsave.relocate(250, 450);
        bsave.setOnMouseEntered((event) -> {    
            bsave.setBlendMode(BlendMode.BLUE);
        });
        bsave.setOnMouseExited((event) -> {    
            bsave.setBlendMode(null);
        });
//        bsave.setOnMouseClicked((event) -> {    // lambda expression
//            //ToggleButton source = (ToggleButton) event.getSource();
//            pause_exitmenu e=new pause_exitmenu(stage);
////            Stage stage2=new Stage();
//            e.start();
////            stage.close();
//        });

        Image image7=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\exit2.png");
        ImageView pb3=new ImageView(image7);
        pb3.setFitHeight(70);
        pb3.setFitWidth(150);
        //pb.relocate(20, 100);
        Button bexit = new Button("",pb3);
        bexit.relocate(400, 600);
        bexit.setOnMouseEntered((event) -> {    
            bexit.setBlendMode(BlendMode.BLUE);
        });
        bexit.setOnMouseExited((event) -> {    
            bexit.setBlendMode(null);
        });
        bexit.setOnMouseClicked((event) -> {    // lambda expression
            //ToggleButton source = (ToggleButton) event.getSource();
        	mediaPlayerHS.play();
            Main e=new Main();
            Stage stage2=new Stage();
            e.start(stage2);
            stage.close();
        });

        Image image6=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\unnamed.png");
        ImageView pb4=new ImageView(image6);
        pb4.setFitHeight(50);
        pb4.setFitWidth(50);
//        pb.relocate(20, 100);
        Button b4 = new Button("",pb4);
        b4.setOnMouseEntered((event) -> {    
            b4.setBlendMode(BlendMode.RED);
        });
        b4.setOnMouseExited((event) -> {    
            b4.setBlendMode(null);
        });
        b4.setOnMouseClicked((event) -> {    // lambda expression
            //ToggleButton source = (ToggleButton) event.getSource();
        	mediaPlayerHS.play();
            playmenu e=new playmenu(stage,playername);
//            Stage stage2=new Stage();
            e.start();
//            stage.close();
        });
//        b.setGraphic(pb);
//        b.resize(50, 50);
        b4.relocate(25, 50);


        BorderPane vbox2 = new BorderPane();

		/* StackPane */ vbox1=new StackPane();
        vbox1.getChildren().add(vbox2);
        vbox2.setMaxSize(500, 700);
        vbox2.setMinSize(500, 700);
        {
            vbox2.getChildren().add(iwbg);
            vbox2.getChildren().add(b4);
            vbox2.getChildren().add(bresume);
            vbox2.getChildren().add(brestart);
            vbox2.getChildren().add(bsave);
            vbox2.getChildren().add(bexit);
        }
		/* Scene */ sc = new Scene(vbox1, 500,700);
        stage.setResizable(true);

//        stage.setScene(sc);

        stage.show();
    }
}