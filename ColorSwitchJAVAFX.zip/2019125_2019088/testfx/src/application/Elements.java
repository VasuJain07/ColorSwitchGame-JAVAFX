package application;

import javafx.scene.Group;

public abstract class Elements {
	double[] Position=new double[2];
	public double[] getPostion() {
		return Position;
	}
	public void setPosition(double pos[]) {
		Position=pos;
	}
	abstract Group action();
}
