package application;
import java.awt.Color;

import javafx.geometry.Pos;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.*;
import java.io.FileInputStream;

import javafx.animation.RotateTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.control.*;
import javafx.scene.effect.BlendMode;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;


public class enternameclass {
	public Stage stage;
	public enternameclass(Stage stage) {
		this.stage=stage;
	}
	public String playername;
    
    public void start()
    {
    	Media hs = new Media(getClass().getResource("button.wav").toString());
//		Media hs= new Media("jump.mp3");
		MediaPlayer mediaPlayerHS = new MediaPlayer(hs);
		
		{
			mediaPlayerHS.setAutoPlay(false);
			mediaPlayerHS.setCycleCount(1);
		
		}
    	Image image4=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\enter.png");
    	ImageView pb2=new ImageView(image4);
    	pb2.setFitHeight(150);
        pb2.setFitWidth(150);
//        pb.relocate(20, 100);
    	Button b2 = new Button("",pb2);
    	b2.setOnMouseEntered((event) -> {    
            b2.setBlendMode(BlendMode.BLUE);
        });
        b2.setOnMouseExited((event) -> {    
            b2.setBlendMode(null);
        });
//        b2.setOnAction((event) -> {    // lambda expression
//            //ToggleButton source = (ToggleButton) event.getSource();
//            playmenu e=new playmenu(stage,playername);
//            String playername=tf.getText();
//            System.out.println(playername);
////            Stage stage3=new Stage();
//            e.start();
////            stage.close();
//        });
//        b.setGraphic(pb);
//        b.resize(50, 50);
        b2.relocate(400, 500);
        
    	Image image3=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\unnamed.png");
    	ImageView pb=new ImageView(image3);
    	pb.setFitHeight(50);
        pb.setFitWidth(50);
//        pb.relocate(20, 100);
    	Button b = new Button("",pb);
        b.setOnAction((event) -> {    // lambda expression
        	mediaPlayerHS.play();
            //ToggleButton source = (ToggleButton) event.getSource();
            Main e=new Main();
//            Stage stage2=new Stage();
            e.start(stage);
//            stage.close();
        });
//        b.setGraphic(pb);
//        b.resize(50, 50);
        b.relocate(25, 50);
        b.setOnMouseEntered((event) -> {    
            b.setBlendMode(BlendMode.RED);
        });
        b.setOnMouseExited((event) -> {    
            b.setBlendMode(null);
        });
    	Image imagebg=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\2131.jpg");
    	ImageView iwbg=new ImageView(imagebg);
    	iwbg.setFitHeight(700);
        iwbg.setFitWidth(500);
    	
        Image image=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\black2.jpg");
        ImageView iw = new ImageView(image);
        iw.setFitHeight(700);
        iw.setFitWidth(500);
//        iw.relocate(0, 200);

        Image image1=new Image("file:D:\\\\STUDY\\\\SEM_3\\\\AP\\\\entername.gif");
        ImageView iw1=new ImageView(image1);
        iw1.setFitHeight(150);
        iw1.setFitWidth(400);
        iw1.relocate(50,200);

        TextField tf = new TextField();
        tf.setMaxWidth(340);
        tf.setMaxHeight(10);
        tf.setBlendMode(BlendMode.DIFFERENCE);
//        tf.setText("Enter name here");
        tf.setFont(Font.font("Verdana",FontWeight.BOLD,30));
        tf.setAlignment(Pos.CENTER);
        b2.setOnAction((event) -> {    // lambda expression
            //ToggleButton source = (ToggleButton) event.getSource();
//            playmenu e=new playmenu(stage,playername);
        	mediaPlayerHS.play();
            playername=tf.getText();
            System.out.println(playername);
            playmenu e=new playmenu(stage,playername);
//            Stage stage3=new Stage();
            e.start();
//            stage.close();
        });

        BorderPane vbox2 = new BorderPane();
        
        StackPane vbox1=new StackPane();
        vbox1.getChildren().add(vbox2);
        vbox2.setMaxSize(500, 700);
        vbox2.setMinSize(500, 700);
        //        vbox2.setBackground(new Background());
        {
        	vbox2.getChildren().add(iwbg);
            vbox2.getChildren().add(iw);
            vbox2.getChildren().add(iw1);
            vbox2.getChildren().add(b);
            vbox2.getChildren().add(b2);
            vbox1.getChildren().add(tf);
        }
//        String playername=tf.getText();
//        System.out.println(playername);

        Scene sc = new Scene(vbox1, 500,650);
        stage.setResizable(true);

        stage.setScene(sc);

        stage.show();
    }
}
